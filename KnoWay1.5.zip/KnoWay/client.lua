-- ==============================
-- INITIALIZATION
-- ==============================
local resourceName = GetCurrentResourceName()
local configFile = LoadResourceFile(resourceName, "config.lua")
local chunk, err = load(configFile)
local Config

if chunk then
    Config = chunk()
else
    print("^1[ERROR] Failed to load config.lua: " .. (err or "File not found") .. "^7")
    return 
end

local activeVivanite = {}

-- ==============================
-- HELPER FUNCTIONS
-- ==============================
local function LoadModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end
end

local function CleanupTable()
    for veh, _ in pairs(activeVivanite) do
        if not DoesEntityExist(veh) then
            activeVivanite[veh] = nil
        end
    end
end

function tablelength(t)
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    return count
end

-- ==============================
-- VEHICLE CUSTOMIZATION
-- ==============================
local function ApplyCustomization(vehicle)
    -- 1. Apply Door Locks
    if Config.isAlwaysLocked then
        SetVehicleDoorsLocked(vehicle, 2) -- 2 = Locked (Cannot be opened)
    else
        SetVehicleDoorsLocked(vehicle, 1) -- 1 = Unlocked
    end

    -- 2. Apply Colors (White vs Multi-Color)
    if Config.isOnlyWhiteKnoWay then
        -- Force Metallic White (111)
        SetVehicleColours(vehicle, 111, 111)
        SetVehicleExtraColours(vehicle, 111, 156) 
        if SetVehicleDashboardColour then SetVehicleDashboardColour(vehicle, 111) end
        if SetVehicleInteriorColour then SetVehicleInteriorColour(vehicle, 111) end
    else
        -- Random Colors
        local prim = math.random(0, 159)
        local sec = math.random(0, 159)
        SetVehicleColours(vehicle, prim, sec)
        SetVehicleExtraColours(vehicle, math.random(0, 159), 156)
        if SetVehicleDashboardColour then SetVehicleDashboardColour(vehicle, prim) end
        if SetVehicleInteriorColour then SetVehicleInteriorColour(vehicle, sec) end
    end

    -- 3. Apply Specific Mods/Liveries
    SetVehicleModKit(vehicle, 0)
    SetVehicleMod(vehicle, 11, GetNumVehicleMods(vehicle, 11) - 1, false) -- Engine
    SetVehicleMod(vehicle, 48, Config.LIVERY_INDEX, false)               -- Livery
    SetVehicleMod(vehicle, 6, Config.GRILLE_MOD, false)                  -- Grille
end

local function CreateInvisibleDriver(vehicle)
    LoadModel(Config.DRIVER_MODEL)
    local ped = CreatePedInsideVehicle(
        vehicle,
        26,
        Config.DRIVER_MODEL,
        -1,
        true,
        false
    )
    
    -- Make driver invisible and non-reactive
    SetEntityVisible(ped, false, false)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedCanRagdoll(ped, false)
    SetEntityCollision(ped, false, false)
    
    -- Driving behavior
    SetDriverAbility(ped, 1.0)
    SetDriverAggressiveness(ped, 0.0)
    TaskVehicleDriveWander(ped, vehicle, 20.0, 786603)
    
    return ped
end

-- ==============================
-- MAIN CONTROL THREAD
-- ==============================
CreateThread(function()
    LoadModel(Config.VEHICLE_MODEL)
    LoadModel(Config.DRIVER_MODEL)

    while true do
        Wait(2000) -- Check for traffic every 2 seconds
        CleanupTable()

        if tablelength(activeVivanite) < Config.MAX_ACTIVE then
            local vehicles = GetGamePool("CVehicle")
            local playerVeh = GetVehiclePedIsIn(PlayerPedId(), false)

            for _, veh in ipairs(vehicles) do
                if DoesEntityExist(veh)
                and not activeVivanite[veh]
                and GetEntityModel(veh) ~= Config.VEHICLE_MODEL
                and veh ~= playerVeh
                and math.random() < Config.SPAWN_CHANCE then
                    
                    if tablelength(activeVivanite) >= Config.MAX_ACTIVE then break end

                    -- Remove original driver
                    local driver = GetPedInVehicleSeat(veh, -1)
                    if driver ~= 0 and driver ~= PlayerPedId() then
                        DeleteEntity(driver)
                    end

                    -- Swap vehicle
                    local coords = GetEntityCoords(veh)
                    local heading = GetEntityHeading(veh)
                    DeleteEntity(veh)

                    local newVeh = CreateVehicle(
                        Config.VEHICLE_MODEL,
                        coords.x, coords.y, coords.z,
                        heading,
                        true, false
                    )

                    -- Setup New Vehicle
                    SetVehicleOnGroundProperly(newVeh)
                    SetEntityAsMissionEntity(newVeh, false, false)
                    
                    ApplyCustomization(newVeh)
                    CreateInvisibleDriver(newVeh)
                    
                    activeVivanite[newVeh] = true
                end
            end
        end
    end
end)