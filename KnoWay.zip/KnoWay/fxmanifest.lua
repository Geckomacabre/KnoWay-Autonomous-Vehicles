fx_version 'cerulean'
game 'gta5'

author 'Geckomacabre'
description 'Spawns vivanite2 traffic with invisible drivers like GTAO'
client_script 'client.lua'
shared_script 'config.lua'