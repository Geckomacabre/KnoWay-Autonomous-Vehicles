-- client.lua
local resourceName = GetCurrentResourceName()
local configFile = LoadResourceFile(resourceName, "config.lua")
local chunk, err = load(configFile)
local Config
if chunk then
    Config = chunk()
else
    print("^1[ERROR] Failed to load config.lua: " .. (err or "File not found/missing") .. "^7")
    return -- Stop script to avoid crashes
end

-- ==============================
-- STATE
-- ==============================
local activeVivanite = {}

-- ==============================
-- UTIL
-- ==============================
local function LoadModel(model)
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end
end

local function CleanupTable()
    for veh, _ in pairs(activeVivanite) do
        if not DoesEntityExist(veh) then
            activeVivanite[veh] = nil
        end
    end
end

local function CreateInvisibleDriver(vehicle)
    LoadModel(Config.DRIVER_MODEL)
    local ped = CreatePedInsideVehicle(
        vehicle,
        26,
        Config.DRIVER_MODEL,
        -1,
        true,
        false
    )
    -- Invisible & safe
    SetEntityVisible(ped, false, false)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedCanRagdoll(ped, false)
    SetEntityCollision(ped, false, false)
    -- Driving behavior
    SetDriverAbility(ped, 1.0)
    SetDriverAggressiveness(ped, 0.0)
    TaskVehicleDriveWander(
        ped,
        vehicle,
        20.0,
        786603
    )
    return ped
end

-- ==============================
-- MAIN LOOP
-- ==============================
CreateThread(function()
    LoadModel(Config.VEHICLE_MODEL)
    LoadModel(Config.DRIVER_MODEL)
    while true do
        Wait(2000)
        CleanupTable()
        if tablelength(activeVivanite) >= Config.MAX_ACTIVE then
            goto continue
        end
        local vehicles = GetGamePool("CVehicle")
        local playerVeh = GetVehiclePedIsIn(PlayerPedId(), false)
        for _, veh in ipairs(vehicles) do
            if DoesEntityExist(veh)
            and not activeVivanite[veh]
            and GetEntityModel(veh) ~= Config.VEHICLE_MODEL
            and veh ~= playerVeh
            and math.random() < Config.SPAWN_CHANCE then
                if tablelength(activeVivanite) >= Config.MAX_ACTIVE then
                    break
                end
                -- Delete existing driver if any
                local driver = GetPedInVehicleSeat(veh, -1)
                if driver ~= 0 and driver ~= PlayerPedId() then
                    DeleteEntity(driver)
                end
                local coords = GetEntityCoords(veh)
                local heading = GetEntityHeading(veh)
                DeleteEntity(veh)
                local newVeh = CreateVehicle(
                    Config.VEHICLE_MODEL,
                    coords.x,
                    coords.y,
                    coords.z,
                    heading,
                    true,
                    false
                )
                SetVehicleOnGroundProperly(newVeh)
                SetEntityAsMissionEntity(newVeh, false, false)
                SetVehicleDoorsLocked(newVeh, 1)
                -- Mods & Livery
                SetVehicleModKit(newVeh, 0)
                SetVehicleMod(newVeh, 11, GetNumVehicleMods(newVeh, 11) - 1, false)
                SetVehicleMod(newVeh, 48, Config.LIVERY_INDEX, false)
                SetVehicleMod(newVeh, 6, Config.GRILLE_MOD, false)
                CreateInvisibleDriver(newVeh)
                activeVivanite[newVeh] = true
            end
        end
        ::continue::
    end
end)

-- ==============================
-- HELPER
-- ==============================
function tablelength(t)
    local count = 0
    for _ in pairs(t) do count = count + 1 end
    return count
end
