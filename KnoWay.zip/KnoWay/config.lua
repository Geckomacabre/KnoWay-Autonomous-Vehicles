-- config.lua
local Config = {}

Config.VEHICLE_MODEL = `vivanite2`
Config.LIVERY_INDEX = 0 -- Livery #2 (0-based)
Config.GRILLE_MOD = 0 -- CHANGE if needed
Config.SPAWN_CHANCE = 0.95 -- 15% chance
Config.MAX_ACTIVE = 25 -- HARD LIMIT
Config.DRIVER_MODEL = `a_m_y_business_01`

return Config